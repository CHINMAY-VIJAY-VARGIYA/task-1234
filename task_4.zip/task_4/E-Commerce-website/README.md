# E-Commerce-website
Create a E-commerce website for fresh food delivering, fully responsive website . Using HTML, CSS, Java-Script and Media Queries.
